﻿namespace UniversityWebSite.Response
{
    public class ApiResponse
    {
        public bool TransactionStatus { get; set; }
        public string Response { get; set; }

    }
}
